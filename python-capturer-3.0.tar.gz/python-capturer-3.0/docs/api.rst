API documentation
=================

The following API documentation was automatically generated from the source
code of `capturer` |release|:

.. contents::
   :local:

:mod:`capturer`
---------------

.. automodule:: capturer
   :members:
